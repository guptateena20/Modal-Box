import React from 'react';
import './App.css';
import Modal from './Components/Modal';
import {ModalContextProvider}  from "./Components/Modalcontext"
import "./Styles/ModalBox.css"

function App() {
  return (

    <ModalContextProvider>
      <Modal />
    </ModalContextProvider>

  );
}

export default App;
