import React from 'react'
import ModalBox from './ModalBox'
import { useModal } from './Modalcontext'


const Modal = () => {
    const md = useModal()
    console.log(md);
    const handleShow = () => {
        md.showModal(<ModalBox/>)
    }

    return (
        <>
            <div className='show_modal_btn_div'>
                <button className="show_modal_btn" onClick = {handleShow}>Show Modal</button>
            </div>
            
        </>
    )
}

export default Modal
